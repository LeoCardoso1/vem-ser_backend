package com.dbc.consumidor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumidorApplicationTests {

	@Test
	void contextLoads() {
	}

}
