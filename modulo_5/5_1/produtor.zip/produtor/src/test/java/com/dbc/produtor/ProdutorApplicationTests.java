package com.dbc.produtor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProdutorApplicationTests {

	@Test
	void contextLoads() {
	}

}
