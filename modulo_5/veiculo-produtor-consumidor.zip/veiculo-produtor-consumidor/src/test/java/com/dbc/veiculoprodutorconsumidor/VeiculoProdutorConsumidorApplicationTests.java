package com.dbc.veiculoprodutorconsumidor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VeiculoProdutorConsumidorApplicationTests {

	@Test
	void contextLoads() {
	}

}
